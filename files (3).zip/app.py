"""MacroSnap - chat with an AI nutrition buddy, then send the summary to WhatsApp.

Run with:  streamlit run app.py
"""

import re

import streamlit as st
from google import genai
from google.genai import types
from twilio.base.exceptions import TwilioRestException
from twilio.rest import Client as TwilioClient

from prompts import SUMMARY_PROMPT, SYSTEM_PROMPT

st.set_page_config(page_title="MacroSnap", page_icon="🥗", layout="centered")


# ----------------------------------------------------------------------------
# Setup: clients and helpers
# ----------------------------------------------------------------------------
def get_secret(key: str, default: str | None = None) -> str | None:
    try:
        return st.secrets[key]
    except Exception:
        return default


GEMINI_API_KEY = get_secret("GEMINI_API_KEY")
GEMINI_MODEL = get_secret("GEMINI_MODEL", "gemini-2.5-flash")
TWILIO_SID = get_secret("TWILIO_ACCOUNT_SID")
TWILIO_TOKEN = get_secret("TWILIO_AUTH_TOKEN")
TWILIO_FROM = get_secret("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")

if not GEMINI_API_KEY:
    st.error(
        "Missing GEMINI_API_KEY. Copy `.streamlit/secrets.toml.example` to "
        "`.streamlit/secrets.toml` and add your keys."
    )
    st.stop()


@st.cache_resource
def get_gemini_client(api_key: str) -> genai.Client:
    return genai.Client(api_key=api_key)


gemini = get_gemini_client(GEMINI_API_KEY)


def normalize_phone(raw: str) -> str | None:
    """Return a number in E.164 format (+91XXXXXXXXXX) or None if invalid.

    A bare 10-digit number is assumed to be Indian (+91).
    """
    digits = re.sub(r"[^\d+]", "", raw.strip())
    if digits.startswith("+"):
        number = "+" + re.sub(r"\D", "", digits)
    else:
        only = re.sub(r"\D", "", digits)
        if len(only) == 10:
            number = "+91" + only
        elif len(only) == 12 and only.startswith("91"):
            number = "+" + only
        else:
            return None
    return number if 11 <= len(number) <= 16 else None


def build_contents(messages: list[dict]) -> list[types.Content]:
    """Convert our stored chat messages into Gemini 'contents'."""
    contents = []
    for m in messages:
        parts = []
        for img in m.get("images", []):
            parts.append(types.Part.from_bytes(data=img["data"], mime_type=img["mime"]))
        if m.get("text"):
            parts.append(types.Part.from_text(text=m["text"]))
        if parts:
            role = "user" if m["role"] == "user" else "model"
            contents.append(types.Content(role=role, parts=parts))
    return contents


def ask_gemini(messages: list[dict]) -> str:
    response = gemini.models.generate_content(
        model=GEMINI_MODEL,
        contents=build_contents(messages),
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            temperature=0.4,
        ),
    )
    return response.text or "Sorry, I couldn't come up with an answer. Please try again."


def make_whatsapp_summary(name: str, messages: list[dict]) -> str:
    """Ask Gemini to condense the chat into a short WhatsApp message."""
    transcript_lines = []
    for m in messages:
        who = name if m["role"] == "user" else "MacroSnap"
        note = " [sent a meal photo]" if m.get("images") else ""
        transcript_lines.append(f"{who}:{note} {m.get('text', '')}".strip())
    transcript = "\n".join(transcript_lines)

    response = gemini.models.generate_content(
        model=GEMINI_MODEL,
        contents=SUMMARY_PROMPT.format(name=name) + "\n\nCHAT:\n" + transcript,
        config=types.GenerateContentConfig(temperature=0.3),
    )
    return (response.text or "").strip()[:1500]  # WhatsApp body limit is 1600 chars


def send_whatsapp(to_number: str, body: str) -> str:
    client = TwilioClient(TWILIO_SID, TWILIO_TOKEN)
    msg = client.messages.create(
        from_=TWILIO_FROM,
        to=f"whatsapp:{to_number}",
        body=body,
    )
    return msg.sid


# ----------------------------------------------------------------------------
# Session state
# ----------------------------------------------------------------------------
if "user" not in st.session_state:
    st.session_state.user = None  # {"name": ..., "phone": ...}
if "messages" not in st.session_state:
    st.session_state.messages = []

# ----------------------------------------------------------------------------
# Step 1: ask for name + WhatsApp number (only once)
# ----------------------------------------------------------------------------
st.title("🥗 MacroSnap")
st.caption("Snap your meal or ask a question. Get instant calories and macros.")

if st.session_state.user is None:
    st.subheader("Let's get started")
    with st.form("signup"):
        name = st.text_input("Your name")
        phone = st.text_input(
            "Your WhatsApp number",
            placeholder="e.g. 9876543210 or +919876543210",
            help="10-digit Indian numbers are assumed to be +91.",
        )
        go = st.form_submit_button("Start chatting")

    if go:
        clean_phone = normalize_phone(phone)
        if not name.strip():
            st.warning("Please enter your name.")
        elif clean_phone is None:
            st.warning("That WhatsApp number doesn't look right. Please check it.")
        else:
            st.session_state.user = {"name": name.strip(), "phone": clean_phone}
            st.session_state.messages = [
                {
                    "role": "assistant",
                    "text": f"Hi {name.strip()}! 👋 I'm MacroSnap. Send me a photo of your "
                    "meal or ask me about any food, and I'll estimate the calories "
                    "and macros.",
                }
            ]
            st.rerun()
    st.stop()

user = st.session_state.user

# ----------------------------------------------------------------------------
# Sidebar: user info + send-to-WhatsApp button
# ----------------------------------------------------------------------------
with st.sidebar:
    st.header(f"Hi, {user['name']} 👋")
    st.write(f"📱 {user['phone']}")
    st.divider()

    has_chat = any(m["role"] == "user" for m in st.session_state.messages)
    if st.button("📤 Send summary to WhatsApp", disabled=not has_chat, use_container_width=True):
        if not (TWILIO_SID and TWILIO_TOKEN):
            st.error("Twilio keys are missing in secrets.toml.")
        else:
            with st.spinner("Writing your summary and sending it..."):
                try:
                    summary = make_whatsapp_summary(user["name"], st.session_state.messages)
                    send_whatsapp(user["phone"], summary)
                    st.success("Sent! Check your WhatsApp ✅")
                except TwilioRestException as e:
                    st.error(
                        f"Twilio error: {e.msg}\n\n"
                        "Have you joined the sandbox? Send the join code to the sandbox "
                        "number from this WhatsApp number first."
                    )
                except Exception as e:  # noqa: BLE001
                    st.error(f"Something went wrong: {e}")

    if st.button("🗑️ Clear chat", use_container_width=True):
        st.session_state.messages = st.session_state.messages[:1]
        st.rerun()

    if st.button("Switch user", use_container_width=True):
        st.session_state.user = None
        st.session_state.messages = []
        st.rerun()

# ----------------------------------------------------------------------------
# Step 2: the chat
# ----------------------------------------------------------------------------
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        for img in m.get("images", []):
            st.image(img["data"], width=280)
        if m.get("text"):
            st.markdown(m["text"])

prompt = st.chat_input(
    "Ask about a food, or attach a meal photo...",
    accept_file=True,
    file_type=["jpg", "jpeg", "png", "webp"],
)

if prompt:
    text = (prompt.text or "").strip()
    images = [
        {"data": f.getvalue(), "mime": f.type or "image/jpeg"} for f in (prompt.files or [])
    ]
    if images and not text:
        text = "Please estimate the calories and macros for this meal."

    st.session_state.messages.append({"role": "user", "text": text, "images": images})
    with st.chat_message("user"):
        for img in images:
            st.image(img["data"], width=280)
        st.markdown(text)

    with st.chat_message("assistant"):
        with st.spinner("Analysing..."):
            try:
                reply = ask_gemini(st.session_state.messages)
            except Exception as e:  # noqa: BLE001
                reply = f"😕 I hit an error talking to Gemini: `{e}`"
        st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "text": reply})
    st.rerun()
